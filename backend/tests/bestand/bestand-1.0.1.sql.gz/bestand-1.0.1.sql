BEGIN TRANSACTION;
CREATE TABLE accounts (
	id INTEGER NOT NULL, 
	name VARCHAR(64) NOT NULL, 
	display_name VARCHAR(80) NOT NULL, 
	whats_new_seen VARCHAR(32) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	sign_in VARCHAR(16) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	password_changed_at DATETIME, 
	email VARCHAR(255) NOT NULL, 
	email_source VARCHAR(16) DEFAULT '' NOT NULL, 
	provider_email VARCHAR(255) DEFAULT '' NOT NULL, 
	provider_email_off VARCHAR(255) DEFAULT '' NOT NULL, 
	language VARCHAR(16) NOT NULL, 
	browser_language VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_seen_at DATETIME, 
	failed_logins INTEGER NOT NULL, 
	locked_until DATETIME, 
	blocked_at DATETIME, 
	deleted_at DATETIME, 
	password_reset_notice BOOLEAN DEFAULT 0 NOT NULL, 
	storage_limit INTEGER, 
	totp_secret_enc TEXT NOT NULL, 
	totp_recovery TEXT NOT NULL, 
	totp_last_step INTEGER NOT NULL, 
	avatar BLOB, 
	avatar_at DATETIME, 
	preferences JSON, 
	device_key VARCHAR(64) NOT NULL, 
	sync_seq INTEGER DEFAULT '0' NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
INSERT INTO "accounts" VALUES(1,'betrieb','Betrieb Beispiel','1.0.1','operator','password','$argon2id$v=19$m=1024,t=1,p=1$gl7/XCXsjR9Al17g5WOOQQ$2T5VsxqunJPtZzRXGWkO0sqCdHUmJR4OFrCT/RW6/ac','2026-11-24 19:05:49.560360','betrieb@example.com','','','','de','','2026-11-24 19:05:49.563603','2026-11-24 19:05:52.081453',0,NULL,NULL,NULL,0,NULL,'1011455bf5111c9221c349c25bc5ae64c604303f6d31440d2c904e12410a4e5a5fdd7a535ccd03ca77fd689da5ec1291d84b82b3bc100a5866619d9c','["e040b90f1e0f5c706886877aa3abb811d78a0fed0aa381fe13952b4c77cfe777", "381c34dec6252f79f06ea8273d17c4a85a2e6c0aa595192f48907ddc7a4ec97e", "225ab459f55927a79fcc600d3058e82eecad2cffdcc18e61a5f22f98164eda50", "2a5e403781cdb5812b9ed9586433420a055d672589e66ab4ea80e4a6da81f367", "2a4c4f2d20dc84e7e03149166c3883a75a2048d3697adce34271df46602790a5", "379af3e21e6d14548174f1609f3d8e32b6a8f721b8f93c26bc3930f0305f3062", "f871a43f9ff4bcdbf3f27dae62397746bee942cefe6a1c4c56bc20eb7931e545", "5a2c02e3e6f198429ff62e8c1ad828fc634068421bb29a1eb1b84deb38156c1f"]',59851571,NULL,NULL,NULL,'7DcC7AI_fQOOakj3DQIBfRJN_nxJRJIZ',0);
INSERT INTO "accounts" VALUES(2,'erika-muster','Erika Muster','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$HnscDK6JWh/+DFZ/Th9WyA$1xJYlH7XkQNTjwkcCDVxHEZND2QfWMQnY40yqx/9iYc','2026-11-24 19:05:49.960880','','','','','','','2026-11-24 19:05:49.961834','2026-11-24 19:05:49.968431',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'EHYxdpzRYKXYr2ASedtcA6tdMs-znnaB',0);
INSERT INTO "accounts" VALUES(3,'jonas','Jonas Beispiel','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$/6D1Shenqq5pazS72VIkZw$/KRsWtCKa0GkEhdFG7Iw0yqcDwbMU5C+UBdUMeNmwNc','2026-11-24 19:05:50.096246','jonas@example.net','','','','','','2026-11-24 19:05:50.097140','2026-11-24 19:05:50.104304',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'fcjM173DrYBMPypgESgEAsrv2pB_iSvw',0);
INSERT INTO "accounts" VALUES(4,'kim','Kim','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$mWFNLljMvDiOSCeQPygkuw$POGZz54bhF40BAd1PaV8jtOW3HSheP7gOiGurkOMBeE','2026-11-24 19:05:50.597240','familie@example.net','','','','','','2026-11-24 19:05:50.598104','2026-11-24 19:05:50.605475',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'kFO4jMigjmLd3R1zjyxGPoebRqTlsiI6',0);
INSERT INTO "accounts" VALUES(5,'lou','Lou','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$OWjk9sZo980AYG4FkD+UTw$FC0iJsQSqAyFF7ma+rpdyQunEXKh2am3BOx6fSjfP/w','2026-11-24 19:05:50.682777','Familie@Example.net','','','','','','2026-11-24 19:05:50.683622','2026-11-24 19:05:50.689945',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'l0V9SwaIX0-iDaCOA410BPnTf_mAl6we',0);
INSERT INTO "accounts" VALUES(6,'mona','Mona Beispiel','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$U9rhsDhPXHAKMBYD9lS9HQ$bBJDqa3A1uPzFO/r8YjMr3zF+ME8pv9Di8iBG7550Wc','2026-11-24 19:05:50.802355','mona@example.com','','','','','','2026-11-24 19:05:50.803168','2026-11-24 19:05:50.906071',0,NULL,NULL,NULL,0,NULL,'3a9f153807b150a27429714fe4e2da2eb9a96d7698d5e17bed891868e5d6462fb30e841f182536bcc11281ae68e29534d60fba243c74c1e0424a71c9','["91503f89b9a82e4c4c2dd5e14b70d9698529b148052db310d6dc513803f4e030", "52fcd1c9b617d04b46a992a0fe60ee6aa8365fff9037b7277ff6f461c82d61fc", "c27df958ff66399116260b6f53cf835077230f2a9036932ec7494094354e17dc", "0ad944c86a387c84c69a42105d24b4516494ac6fb0f64160702ad8240f194516", "88d0b34c8c162d779531f81303be88bef29b09d651dbc916899f90e887b3536a", "109b3e8a5709083ea56791e3bdebd683e9ad6f5513286b37e758cdd311395d8b", "56b05e6e3d808069d5819c4007b5ac852da161f72ea72449b8593260662c7d8b", "e4cbb082bc1c891ce0212309607e2700c1bfb7dcbd360de97d3e15a0ef91cb86"]',59851571,NULL,NULL,NULL,'1R86GNjX9yWiFQTyXBNrjnyjhDDWDSl7',0);
INSERT INTO "accounts" VALUES(7,'sam','Sam','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$OYba45oS2zsJqb5gkXN7UA$ZlgUWesVRUQed8eUj7kfBTsshg3cae74xNAhrXi96cM','2026-11-24 19:05:51.139328','sam@example.org','provider','','','','','2026-11-24 19:05:51.140160','2026-11-24 19:05:51.170130',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'rXGxWB9Nsq-8JahrnBrdc0KYXdepgrvE',0);
INSERT INTO "accounts" VALUES(8,'robin.sso','','1.0.1','operator','oidc','',NULL,'robin@sso.example.com','provider','','','','','2026-11-24 19:05:51.701245','2026-11-24 19:05:51.719742',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'f0TeIecIeQeah3vsBmlISe-BbYbWshYb',0);
INSERT INTO "accounts" VALUES(9,'gesperrt','Gesperrt Beispiel','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$0IZt/2W0egMON8JL2z2mqg$Ophn+Tmp74Flaq7UcxOuhR3MDjcIkfIAuyaoMr5bgR4','2026-11-24 19:05:51.801142','gesperrt@example.com','','','','','','2026-11-24 19:05:51.801982','2026-11-24 19:05:51.808184',0,NULL,'2026-11-24 19:05:51.934212',NULL,0,NULL,'','',0,NULL,NULL,NULL,'VpT4pFqDBP0ls_5cqc6Y1V81vwCzPKKs',0);
INSERT INTO "accounts" VALUES(10,'weg','Weg Beispiel','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$+piXPY2pugoUpsn0ZwRiNA$/2KqLUxwYdbAIkxuCcMkJqOgHelbz4AfeNZir6ZRCag','2026-11-24 19:05:51.878751','weg@example.com','','','','','','2026-11-24 19:05:51.879089','2026-11-24 19:05:51.885774',0,NULL,NULL,'2026-11-24 19:05:51.987494',0,NULL,'','',0,NULL,NULL,NULL,'vtFqBgLmrgWV8Mms90jvv1VMJhnW-7gd',0);
CREATE TABLE api_refs (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	external_ref VARCHAR(200) NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_api_refs_account_ref UNIQUE (account_id, external_ref), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE api_tokens (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	kind VARCHAR(16) NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	level VARCHAR(8) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	prefix VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	expires_at DATETIME, 
	client_id VARCHAR(64), 
	refresh_hash VARCHAR(64), 
	refresh_old_hash VARCHAR(64), 
	signed_in_at DATETIME, 
	allow_mcp BOOLEAN, 
	folder_ids JSON, 
	blocked_at DATETIME, 
	device_kind VARCHAR(8) DEFAULT '' NOT NULL, 
	via_token_id INTEGER, 
	full_cursor INTEGER, 
	full_start INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
INSERT INTO "api_tokens" VALUES(1,3,'api','Dashboard','read','74a550df77b49596cb47a292166cbc961f1dce9cc970a4e02f1a6c9cb2d8913b','nn_api_best','2026-11-24 19:05:50.517787',NULL,NULL,NULL,NULL,NULL,NULL,0,'null',NULL,'',NULL,NULL,NULL);
INSERT INTO "api_tokens" VALUES(2,6,'device','iPhone (Bestand)','write','d33e033790d23d9a4deca35c0ffe67b8f9191f05df864719e1465d3b5e9f0944','nnd_best','2026-11-24 19:05:51.068132',NULL,NULL,NULL,NULL,NULL,NULL,0,'null',NULL,'ios',NULL,NULL,NULL);
CREATE TABLE app_codes (
	code_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	state VARCHAR(128) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	PRIMARY KEY (code_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE app_counter (
	id INTEGER NOT NULL, 
	value INTEGER NOT NULL, 
	floor INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO "app_counter" VALUES(1,12,0);
CREATE TABLE app_gone_devices (
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (token_hash)
);
CREATE TABLE app_pairings (
	id VARCHAR(32) NOT NULL, 
	account_id INTEGER NOT NULL, 
	secret_hash VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	device_token_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(device_token_id) REFERENCES api_tokens (id) ON DELETE SET NULL
);
INSERT INTO "app_pairings" VALUES('bestand-kopplung-mona-20',6,'5de22afd532d67117d3eaf0466acfd924008f8bb6104b87d5373065f292c43ad','2026-11-24 19:05:50.965152','2026-11-24 19:15:50.965152','2026-11-24 19:05:51.052405',2);
CREATE TABLE app_tombstones (
	id INTEGER NOT NULL, 
	seq INTEGER NOT NULL, 
	kind VARCHAR(8) NOT NULL, 
	object_id VARCHAR(36) NOT NULL, 
	account_id INTEGER, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE attachment_mentions (
	note_id VARCHAR(36) NOT NULL, 
	attachment_id VARCHAR(32) NOT NULL, 
	vouched BOOLEAN DEFAULT 1 NOT NULL, 
	PRIMARY KEY (note_id, attachment_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE attachment_ocr (
	attachment_id VARCHAR(32) NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	pages INTEGER NOT NULL, 
	languages VARCHAR(64) NOT NULL, 
	source VARCHAR(16) NOT NULL, 
	error VARCHAR(32) NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (attachment_id), 
	FOREIGN KEY(attachment_id) REFERENCES attachments (id) ON DELETE CASCADE
);
CREATE TABLE attachment_refs (
	note_id VARCHAR(36) NOT NULL, 
	attachment_id VARCHAR(32) NOT NULL, 
	position INTEGER NOT NULL, 
	PRIMARY KEY (note_id, attachment_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE attachment_texts (
	attachment_id VARCHAR(32) NOT NULL, 
	page INTEGER NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	text TEXT NOT NULL, 
	language VARCHAR(8) NOT NULL, 
	source VARCHAR(16) NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (attachment_id, page), 
	FOREIGN KEY(attachment_id) REFERENCES attachments (id) ON DELETE CASCADE
);
CREATE TABLE attachments (
	id VARCHAR(32) NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	owner_id INTEGER NOT NULL, 
	uploaded_by INTEGER, 
	kind VARCHAR(16) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	mime VARCHAR(100) NOT NULL, 
	size INTEGER NOT NULL, 
	stored INTEGER NOT NULL, 
	width INTEGER, 
	height INTEGER, 
	pages INTEGER, 
	duration_ms INTEGER, 
	has_view BOOLEAN NOT NULL, 
	has_thumb BOOLEAN NOT NULL, 
	inline BOOLEAN NOT NULL, 
	preview_failed BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	unref_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(uploaded_by) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE auth_sessions (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	last_seen_at DATETIME NOT NULL, 
	ip VARCHAR(64) NOT NULL, 
	user_agent VARCHAR(255) NOT NULL, 
	provider_checked BOOLEAN DEFAULT 0 NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "auth_sessions" VALUES(1,'b422c14c9ef3e4681ba443b1a39312b292af87fa08337d91d44302ab157949e9',1,'2026-11-24 19:05:49.589410','2026-12-24 19:05:49.581429','2026-11-24 19:05:49.589418','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(2,'367c590bb0c34f6af42b4dd52f1fdded0b747d12de544bd6459f63f6349138c5',2,'2026-11-24 19:05:49.973441','2026-12-24 19:05:49.968270','2026-11-24 19:05:49.973449','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(3,'fcf32653b0288d2ea7a8aa2be37d3bac1cc8d3c2b082f7cbb93f96c6f2e95bf3',3,'2026-11-24 19:05:50.110509','2026-12-24 19:05:50.104166','2026-11-24 19:05:50.110516','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(4,'2dfceabe532c5297863167a4eb4b7616bd4ef6fc325725b845ed4d7292fd74fe',4,'2026-11-24 19:05:50.612511','2026-12-24 19:05:50.605314','2026-11-24 19:05:50.612520','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(5,'28333cd9947439ddca3b18c9d2a841fb085c4ff34b53609f017d9ac9425e1499',5,'2026-11-24 19:05:50.695248','2026-12-24 19:05:50.689800','2026-11-24 19:05:50.695254','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(6,'3d97ea6c1a17b659653008ab65132982f56d9d1ce2f4ba01994862a53b58199c',6,'2026-11-24 19:05:50.817583','2026-12-24 19:05:50.810161','2026-11-24 19:05:50.817590','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(7,'aad3058973b615e8dd96c7c54756705d681a7a295db2830ed0f09bf050ec2ffd',7,'2026-11-24 19:05:51.151048','2026-12-24 19:05:51.146896','2026-11-24 19:05:51.151052','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(8,'633798dfb33f61ae7bc34c0ec50ff5327b8659f0287ac50b10be01801fec59bf',8,'2026-11-24 19:05:51.720722','2026-12-24 19:05:51.719585','2026-11-24 19:05:51.720727','testclient','testclient',1);
INSERT INTO "auth_sessions" VALUES(9,'abf98af92aac081b69123da5fc0d45c28c71e7c9031e39140ad7a0d2d6049675',9,'2026-11-24 19:05:51.813852','2026-12-24 19:05:51.808035','2026-11-24 19:05:51.813859','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(10,'943798215047e60f07228ba3c770ed23590cab5353b755646d49aabedf44da31',10,'2026-11-24 19:05:51.891210','2026-12-24 19:05:51.885694','2026-11-24 19:05:51.891218','testclient','testclient',0);
CREATE TABLE export_jobs (
	id VARCHAR(36) NOT NULL, 
	account_id INTEGER NOT NULL, 
	folder_id VARCHAR(36), 
	label VARCHAR(200) NOT NULL, 
	filename VARCHAR(255) NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	problem VARCHAR(32) NOT NULL, 
	estimate INTEGER NOT NULL, 
	size INTEGER NOT NULL, 
	notes INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	started_at DATETIME, 
	finished_at DATETIME, 
	expires_at DATETIME, 
	seen BOOLEAN DEFAULT 0 NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE folders (
	id VARCHAR(36) NOT NULL, 
	owner_id INTEGER NOT NULL, 
	parent_id VARCHAR(36), 
	kind VARCHAR(16) NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	icon VARCHAR(32) NOT NULL, 
	color VARCHAR(16) NOT NULL, 
	position INTEGER, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	deleted_at DATETIME, 
	deleted_batch VARCHAR(36), 
	sync_seq INTEGER DEFAULT '0' NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(parent_id) REFERENCES folders (id) ON DELETE CASCADE
);
CREATE TABLE invites (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	email VARCHAR(255) NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(created_by) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "invites" VALUES(1,'e0cd71b6fa0ba0cd36b5477861481ff772561fd8429e50e2735cb82ffddb9489','member','gast@example.org',1,'2026-11-24 19:05:52.042680','2026-12-24 19:05:52.042196');
CREATE TABLE nextasks_connections (
	account_id INTEGER NOT NULL, 
	url VARCHAR(500) NOT NULL, 
	token_enc VARCHAR(2000) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	checked_at DATETIME NOT NULL, 
	last_list_id VARCHAR(100) NOT NULL, 
	last_list_name VARCHAR(300) NOT NULL, 
	device_id INTEGER, 
	task_choice TEXT DEFAULT '' NOT NULL, 
	default_list_id VARCHAR(100) DEFAULT '' NOT NULL, 
	PRIMARY KEY (account_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE nextasks_links (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	request_id VARCHAR(64) NOT NULL, 
	position INTEGER NOT NULL, 
	anchor VARCHAR(64) NOT NULL, 
	task_id VARCHAR(100) NOT NULL, 
	task_url VARCHAR(2000) NOT NULL, 
	list_name VARCHAR(300) NOT NULL, 
	due_date DATE, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_nextasks_link_request UNIQUE (account_id, request_id, position), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE note_edits (
	note_id VARCHAR(36) NOT NULL, 
	writer VARCHAR(160) NOT NULL, 
	account_id INTEGER, 
	via VARCHAR(140) NOT NULL, 
	first_at DATETIME NOT NULL, 
	last_at DATETIME NOT NULL, 
	PRIMARY KEY (note_id, writer), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE note_list_views (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	"key" VARCHAR(40) NOT NULL, 
	mode VARCHAR(8) NOT NULL, 
	sort VARCHAR(8) NOT NULL, 
	direction VARCHAR(4) NOT NULL, 
	grouped BOOLEAN NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, "key"), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE note_tags (
	note_id VARCHAR(36) NOT NULL, 
	label VARCHAR(64) NOT NULL, 
	"key" VARCHAR(200) NOT NULL, 
	count INTEGER NOT NULL, 
	PRIMARY KEY (note_id, label), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE note_updates (
	id INTEGER NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	"update" BLOB NOT NULL, 
	account_id INTEGER, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE note_versions (
	id INTEGER NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	created_at DATETIME NOT NULL, 
	started_at DATETIME NOT NULL, 
	state BLOB NOT NULL, 
	title VARCHAR(120) NOT NULL, 
	size INTEGER NOT NULL, 
	authors JSON NOT NULL, 
	restored_from DATETIME, 
	sealed BOOLEAN DEFAULT 0 NOT NULL, 
	sealed_rev INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE notes (
	id VARCHAR(36) NOT NULL, 
	owner_id INTEGER NOT NULL, 
	folder_id VARCHAR(36) NOT NULL, 
	title VARCHAR(120) NOT NULL, 
	title_check BOOLEAN DEFAULT 0 NOT NULL, 
	origin VARCHAR(100) NOT NULL, 
	copied_from VARCHAR(80) DEFAULT '' NOT NULL, 
	ydoc BLOB NOT NULL, 
	text TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	deleted_batch VARCHAR(36), 
	deleted_by_id INTEGER, 
	pinned_at DATETIME, 
	color VARCHAR(16) DEFAULT '' NOT NULL, 
	tasks_done INTEGER, 
	tasks_total INTEGER, 
	listed_at DATETIME, 
	paper VARCHAR(8) DEFAULT 'blank' NOT NULL, 
	icon VARCHAR(32) DEFAULT '' NOT NULL, 
	locked BOOLEAN DEFAULT 0 NOT NULL, 
	sync_seq INTEGER DEFAULT '0' NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(folder_id) REFERENCES folders (id) ON DELETE CASCADE, 
	FOREIGN KEY(updated_by_id) REFERENCES accounts (id) ON DELETE SET NULL, 
	FOREIGN KEY(deleted_by_id) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE notify_baselines (
	note_id VARCHAR(36) NOT NULL, 
	lines JSON NOT NULL, 
	taken_at DATETIME NOT NULL, 
	trashed_by INTEGER, 
	PRIMARY KEY (note_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(trashed_by) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE notify_edits (
	note_id VARCHAR(36) NOT NULL, 
	account_id INTEGER NOT NULL, 
	first_at DATETIME NOT NULL, 
	last_at DATETIME NOT NULL, 
	PRIMARY KEY (note_id, account_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE notify_outbox (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	channel VARCHAR(8) NOT NULL, 
	target_id INTEGER NOT NULL, 
	payload JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	next_try_at DATETIME NOT NULL, 
	attempts INTEGER NOT NULL, 
	sent_at DATETIME, 
	failed_at DATETIME, 
	last_error VARCHAR(40) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE notify_watches (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	note_id VARCHAR(36), 
	folder_id VARCHAR(36), 
	"on" BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, note_id), 
	UNIQUE (account_id, folder_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(folder_id) REFERENCES folders (id) ON DELETE CASCADE
);
CREATE TABLE oauth_clients (
	id VARCHAR(64) NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	redirect_uris JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE TABLE oauth_codes (
	code_hash VARCHAR(64) NOT NULL, 
	client_id VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	redirect_uri VARCHAR(2048) NOT NULL, 
	challenge VARCHAR(128) NOT NULL, 
	level VARCHAR(8) NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (code_hash), 
	FOREIGN KEY(client_id) REFERENCES oauth_clients (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE oauth_spent (
	token_hash VARCHAR(64) NOT NULL, 
	key_id INTEGER NOT NULL, 
	spent_at DATETIME NOT NULL, 
	PRIMARY KEY (token_hash), 
	FOREIGN KEY(key_id) REFERENCES api_tokens (id) ON DELETE CASCADE
);
CREATE TABLE oidc_links (
	id INTEGER NOT NULL, 
	provider_id INTEGER NOT NULL, 
	subject VARCHAR(255) NOT NULL, 
	account_id INTEGER NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	email VARCHAR(320), 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (provider_id, subject), 
	UNIQUE (provider_id, account_id), 
	FOREIGN KEY(provider_id) REFERENCES oidc_providers (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "oidc_links" VALUES(1,1,'bestand-sam',7,'https://sso.example.com','sam@example.org','2026-11-24 19:05:51.381311',NULL);
INSERT INTO "oidc_links" VALUES(2,1,'bestand-robin',8,'https://sso.example.com','robin@sso.example.com','2026-11-24 19:05:51.707827',NULL);
CREATE TABLE oidc_providers (
	id INTEGER NOT NULL, 
	slug VARCHAR(40) NOT NULL, 
	label VARCHAR(64) NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	client_id VARCHAR(255) NOT NULL, 
	client_secret_enc TEXT NOT NULL, 
	scopes VARCHAR(500) NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	auto_create BOOLEAN NOT NULL, 
	trusts_second_factor BOOLEAN NOT NULL, 
	managed VARCHAR(20) NOT NULL, 
	position INTEGER NOT NULL, 
	redirect_path VARCHAR(300) NOT NULL, 
	registered_redirect VARCHAR(500) DEFAULT '' NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (slug)
);
INSERT INTO "oidc_providers" VALUES(1,'sso','SSO','https://sso.example.com','nexnotes-bestand','df04212780c76065c434b7ecf2bb72c31d645ca192781f5e0a7c5ea3f3183bb616f85e3e95e5746074e9','openid profile email',1,0,1,'',0,'','','2026-11-24 19:05:49.840965');
CREATE TABLE password_resets (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "password_resets" VALUES(1,'aba2148f307ba899f3a0c389145ce9c1f22308feccf976156e104183529183be',2,1,'2026-11-24 19:05:52.090819','2026-12-24 19:05:52.088984');
CREATE TABLE push_devices (
	token_id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	ticket TEXT NOT NULL, 
	"key" VARCHAR(64) NOT NULL, 
	updated_at DATETIME NOT NULL, 
	last_ok_at DATETIME, 
	PRIMARY KEY (token_id), 
	FOREIGN KEY(token_id) REFERENCES api_tokens (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE read_links (
	id INTEGER NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	owner_id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	expires_on VARCHAR(10) NOT NULL, 
	expires_at DATETIME NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (note_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
CREATE TABLE sealed_notes (
	note_id VARCHAR(36) NOT NULL, 
	content BLOB NOT NULL, 
	rev INTEGER NOT NULL, 
	saved_at DATETIME NOT NULL, 
	saved_by_id INTEGER, 
	PRIMARY KEY (note_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(saved_by_id) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE settings (
	"key" VARCHAR(64) NOT NULL, 
	value JSON, 
	PRIMARY KEY ("key")
);
INSERT INTO "settings" VALUES('running_version','"1.0.1"');
INSERT INTO "settings" VALUES('tags_rules','"1"');
INSERT INTO "settings" VALUES('webpush_key_enc','"6df6f0b119452d9ed691183e69c7778096b4371a33f5ad41d7dc74195f2730c105a45135d1801a5d693afebb7ad28164b27db5660c8eb2592c3dadf0ccf8d99a02b001798879736b0680b8e3fddc9aaa0599e47a5c5f3c21d37879521a158d82c4073401166d692bcafd5cb05cae10230b4ba9aa4ed3af66a1c76887fd1ccfa54282048189ddbcfac73773f5453508dc105f53285b8bb57dcd45c0089da940a9a53cb5ccdea369615878071119e38b6dd50583bcc3519688f9debc864a8acf5439469e083a0ddedd32b6e4a86633014764648e93348693645e6ea37e00cc40ef10bcef5717dc5e5f1c77eeb8faa2ecc0137f3d4d6d2dd0252448c65cbaa4d2198ec060421786ea2ddc078b6bad"');
INSERT INTO "settings" VALUES('smart_folders_seeded','true');
INSERT INTO "settings" VALUES('smart_folders_seeded_places','true');
INSERT INTO "settings" VALUES('smart_folders_seeded_icons','true');
INSERT INTO "settings" VALUES('smart_folders_seeded_keys','true');
INSERT INTO "settings" VALUES('guide_seeded','true');
INSERT INTO "settings" VALUES('public_url','"https://notes.example.com"');
CREATE TABLE share_notices (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	reason VARCHAR(16) NOT NULL, 
	kind VARCHAR(8) NOT NULL, 
	title VARCHAR(120) NOT NULL, 
	owner_name VARCHAR(80) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE share_pins (
	account_id INTEGER NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	pinned_at DATETIME NOT NULL, 
	PRIMARY KEY (account_id, note_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE shares (
	id INTEGER NOT NULL, 
	owner_id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	note_id VARCHAR(36), 
	folder_id VARCHAR(36), 
	level VARCHAR(8) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, note_id), 
	UNIQUE (account_id, folder_id), 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(folder_id) REFERENCES folders (id) ON DELETE CASCADE
);
CREATE TABLE smart_folders (
	id VARCHAR(36) NOT NULL, 
	owner_id INTEGER NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	name_key VARCHAR(200) NOT NULL, 
	preset VARCHAR(16) NOT NULL, 
	"match" VARCHAR(8) NOT NULL, 
	conditions JSON NOT NULL, 
	icon VARCHAR(32) DEFAULT 'filter' NOT NULL, 
	color VARCHAR(16) DEFAULT '' NOT NULL, 
	position INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	sync_seq INTEGER DEFAULT '0' NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (owner_id, name_key), 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "smart_folders" VALUES('ff682da0-09c9-4bf3-8a14-c02499009f6e',1,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 19:05:49.565442','2026-11-24 19:05:49.565442',3);
INSERT INTO "smart_folders" VALUES('823d66c8-f484-4ceb-8d0c-7bf29e511fbc',1,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 19:05:49.565442','2026-11-24 19:05:49.565442',3);
INSERT INTO "smart_folders" VALUES('75cc0705-3953-4c6d-8fe5-9c32e06dea06',1,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 19:05:49.565442','2026-11-24 19:05:49.565442',3);
INSERT INTO "smart_folders" VALUES('fb9142b9-a038-4fc6-83d0-6bf9ea9b7e4c',2,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 19:05:49.963162','2026-11-24 19:05:49.963162',4);
INSERT INTO "smart_folders" VALUES('4c6c16ac-4da3-4c12-ac62-8712d4a987df',2,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 19:05:49.963162','2026-11-24 19:05:49.963162',4);
INSERT INTO "smart_folders" VALUES('df2884b8-84d2-4712-b555-ceca90a53874',2,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 19:05:49.963162','2026-11-24 19:05:49.963162',4);
INSERT INTO "smart_folders" VALUES('d3d9e92d-9009-4069-9c5a-800c3e48f837',3,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 19:05:50.098499','2026-11-24 19:05:50.098499',5);
INSERT INTO "smart_folders" VALUES('302957c0-a33f-45d7-8f27-31141bce4b9a',3,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 19:05:50.098499','2026-11-24 19:05:50.098499',5);
INSERT INTO "smart_folders" VALUES('85ec3353-78a5-435c-aafa-c606b081815b',3,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 19:05:50.098499','2026-11-24 19:05:50.098499',5);
INSERT INTO "smart_folders" VALUES('5a870b19-cb10-4af9-98ca-a3494a9ca4c1',4,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 19:05:50.599560','2026-11-24 19:05:50.599560',6);
INSERT INTO "smart_folders" VALUES('eb0b17ad-b0de-44d5-a44b-cfd5ba255c04',4,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 19:05:50.599560','2026-11-24 19:05:50.599560',6);
INSERT INTO "smart_folders" VALUES('ca6aa110-b313-4cdc-810a-f38926c2fe4c',4,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 19:05:50.599560','2026-11-24 19:05:50.599560',6);
INSERT INTO "smart_folders" VALUES('8afc937c-79bc-47eb-b630-cdcb14ff904a',5,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 19:05:50.684754','2026-11-24 19:05:50.684754',7);
INSERT INTO "smart_folders" VALUES('8e501b77-0269-4eea-b77d-370efda6247c',5,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 19:05:50.684754','2026-11-24 19:05:50.684754',7);
INSERT INTO "smart_folders" VALUES('7be6e427-1281-483b-b0a8-dda426dbb3b1',5,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 19:05:50.684754','2026-11-24 19:05:50.684754',7);
INSERT INTO "smart_folders" VALUES('8e31dbfe-9a95-4e11-b8f3-d20a674c7924',6,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 19:05:50.804472','2026-11-24 19:05:50.804472',8);
INSERT INTO "smart_folders" VALUES('35b76566-1e0f-467b-8cc3-7e440e1b4756',6,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 19:05:50.804472','2026-11-24 19:05:50.804472',8);
INSERT INTO "smart_folders" VALUES('18b9b4bc-7b87-4490-9980-2d9ee420ccdd',6,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 19:05:50.804472','2026-11-24 19:05:50.804472',8);
INSERT INTO "smart_folders" VALUES('ef83ab52-9b7a-447d-ac06-c1915456d7f9',7,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 19:05:51.141463','2026-11-24 19:05:51.141463',9);
INSERT INTO "smart_folders" VALUES('32049388-fa67-4683-b6fa-d69dd978392b',7,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 19:05:51.141463','2026-11-24 19:05:51.141463',9);
INSERT INTO "smart_folders" VALUES('12c65336-a992-4540-8fca-c9898c9cdbe2',7,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 19:05:51.141463','2026-11-24 19:05:51.141463',9);
INSERT INTO "smart_folders" VALUES('c5f96552-6b3f-4180-8e01-d067fa4f3ec6',8,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 19:05:51.702764','2026-11-24 19:05:51.702764',10);
INSERT INTO "smart_folders" VALUES('d6d9f9d0-28a4-4e68-a9d6-ac46b531abeb',8,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 19:05:51.702764','2026-11-24 19:05:51.702764',10);
INSERT INTO "smart_folders" VALUES('8501b21b-025f-44d5-b698-5ead6134203c',8,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 19:05:51.702764','2026-11-24 19:05:51.702764',10);
INSERT INTO "smart_folders" VALUES('50c83272-cab6-426e-b284-8cf4d3694764',9,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 19:05:51.803283','2026-11-24 19:05:51.803283',11);
INSERT INTO "smart_folders" VALUES('316a3c94-996c-472e-8ad7-8b8d569f98da',9,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 19:05:51.803283','2026-11-24 19:05:51.803283',11);
INSERT INTO "smart_folders" VALUES('60b9c25e-779f-4520-917b-2c9e9072ae4d',9,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 19:05:51.803283','2026-11-24 19:05:51.803283',11);
INSERT INTO "smart_folders" VALUES('39255e6a-7387-428e-b422-e8c1b79078c8',10,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 19:05:51.880281','2026-11-24 19:05:51.880281',12);
INSERT INTO "smart_folders" VALUES('a59b80bb-fe71-4ac1-bac5-9b267eb3da2f',10,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 19:05:51.880281','2026-11-24 19:05:51.880281',12);
INSERT INTO "smart_folders" VALUES('0f3c3027-f547-48c9-a3d9-611c41fe32de',10,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 19:05:51.880281','2026-11-24 19:05:51.880281',12);
CREATE TABLE vault_pending (
	note_id VARCHAR(36) NOT NULL, 
	account_id INTEGER NOT NULL, 
	step VARCHAR(8) NOT NULL, 
	parts JSON NOT NULL, 
	started_at DATETIME NOT NULL, 
	PRIMARY KEY (note_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE vaults (
	account_id INTEGER NOT NULL, 
	kdf JSON NOT NULL, 
	wrapped_key BLOB NOT NULL, 
	auth_hash VARCHAR(64) NOT NULL, 
	epoch INTEGER NOT NULL, 
	failures INTEGER NOT NULL, 
	rounds INTEGER NOT NULL, 
	wait_until DATETIME, 
	created_at DATETIME NOT NULL, 
	changed_at DATETIME NOT NULL, 
	PRIMARY KEY (account_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE webpush_subscriptions (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	session_id INTEGER NOT NULL, 
	endpoint TEXT NOT NULL, 
	p256dh VARCHAR(100) NOT NULL, 
	auth VARCHAR(40) NOT NULL, 
	user_agent VARCHAR(300) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_ok_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(session_id) REFERENCES auth_sessions (id) ON DELETE CASCADE, 
	UNIQUE (endpoint)
);
CREATE TABLE work_jobs (
	id INTEGER NOT NULL, 
	kind VARCHAR(32) NOT NULL, 
	ref VARCHAR(64) NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	run_after DATETIME NOT NULL, 
	attempts INTEGER NOT NULL, 
	account_id INTEGER, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_work_jobs_account_id ON work_jobs (account_id);
CREATE INDEX ix_work_jobs_turn ON work_jobs (state, run_after, id);
CREATE UNIQUE INDEX ix_work_jobs_kind_ref ON work_jobs (kind, ref);
CREATE INDEX ix_app_tombstones_created_at ON app_tombstones (created_at);
CREATE INDEX ix_app_tombstones_seq ON app_tombstones (seq);
CREATE INDEX ix_app_tombstones_account_id ON app_tombstones (account_id);
CREATE INDEX ix_app_gone_devices_account_id ON app_gone_devices (account_id);
CREATE INDEX ix_auth_sessions_account_id ON auth_sessions (account_id);
CREATE INDEX ix_oidc_links_provider_id ON oidc_links (provider_id);
CREATE INDEX ix_oidc_links_account_id ON oidc_links (account_id);
CREATE INDEX ix_password_resets_account_id ON password_resets (account_id);
CREATE INDEX ix_api_tokens_client_id ON api_tokens (client_id);
CREATE INDEX ix_api_tokens_account_id ON api_tokens (account_id);
CREATE INDEX ix_api_tokens_refresh_hash ON api_tokens (refresh_hash);
CREATE INDEX ix_folders_parent_id ON folders (parent_id);
CREATE INDEX ix_folders_owner_id ON folders (owner_id);
CREATE INDEX ix_folders_deleted_at ON folders (deleted_at);
CREATE UNIQUE INDEX uq_folders_one_inbox ON folders (owner_id) WHERE kind = 'inbox';
CREATE INDEX ix_folders_sync_seq ON folders (sync_seq);
CREATE INDEX ix_folders_deleted_batch ON folders (deleted_batch);
CREATE INDEX ix_note_list_views_account_id ON note_list_views (account_id);
CREATE INDEX ix_share_notices_account_id ON share_notices (account_id);
CREATE INDEX ix_smart_folders_owner_id ON smart_folders (owner_id);
CREATE INDEX ix_smart_folders_sync_seq ON smart_folders (sync_seq);
CREATE INDEX ix_oauth_codes_account_id ON oauth_codes (account_id);
CREATE INDEX ix_oauth_codes_client_id ON oauth_codes (client_id);
CREATE INDEX ix_export_jobs_status ON export_jobs (status);
CREATE INDEX ix_export_jobs_account_id ON export_jobs (account_id);
CREATE INDEX ix_app_codes_account_id ON app_codes (account_id);
CREATE INDEX ix_notify_outbox_account_id ON notify_outbox (account_id);
CREATE INDEX ix_notify_outbox_due ON notify_outbox (sent_at, failed_at, next_try_at);
CREATE INDEX ix_notes_deleted_batch ON notes (deleted_batch);
CREATE INDEX ix_notes_locked ON notes (locked);
CREATE INDEX ix_notes_owner_id ON notes (owner_id);
CREATE INDEX ix_notes_sync_seq ON notes (sync_seq);
CREATE INDEX ix_notes_updated_at ON notes (updated_at);
CREATE INDEX ix_notes_folder_id ON notes (folder_id);
CREATE INDEX ix_notes_deleted_at ON notes (deleted_at);
CREATE INDEX ix_oauth_spent_key_id ON oauth_spent (key_id);
CREATE INDEX ix_app_pairings_account_id ON app_pairings (account_id);
CREATE INDEX ix_webpush_subscriptions_account_id ON webpush_subscriptions (account_id);
CREATE INDEX ix_webpush_subscriptions_session_id ON webpush_subscriptions (session_id);
CREATE INDEX ix_push_devices_account_id ON push_devices (account_id);
CREATE INDEX ix_note_updates_note_id ON note_updates (note_id);
CREATE INDEX ix_attachments_note_id ON attachments (note_id);
CREATE INDEX ix_attachments_unref_at ON attachments (unref_at);
CREATE INDEX ix_attachments_owner_created ON attachments (owner_id, created_at);
CREATE INDEX ix_attachments_owner_id ON attachments (owner_id);
CREATE INDEX ix_attachment_refs_attachment ON attachment_refs (attachment_id);
CREATE INDEX ix_attachment_mentions_attachment ON attachment_mentions (attachment_id);
CREATE INDEX ix_shares_account_id ON shares (account_id);
CREATE INDEX ix_shares_note_id ON shares (note_id);
CREATE INDEX ix_shares_folder_id ON shares (folder_id);
CREATE INDEX ix_shares_owner_id ON shares (owner_id);
CREATE INDEX ix_read_links_owner_id ON read_links (owner_id);
CREATE INDEX ix_read_links_expires ON read_links (expires_at);
CREATE INDEX ix_note_tags_key_note ON note_tags ("key", note_id);
CREATE INDEX ix_note_versions_note_id ON note_versions (note_id);
CREATE INDEX ix_note_versions_note_created ON note_versions (note_id, created_at);
CREATE INDEX ix_note_edits_last_at ON note_edits (last_at);
CREATE INDEX ix_api_refs_note_id ON api_refs (note_id);
CREATE INDEX ix_api_refs_account_id ON api_refs (account_id);
CREATE INDEX ix_notify_watches_folder_id ON notify_watches (folder_id);
CREATE INDEX ix_notify_watches_note_id ON notify_watches (note_id);
CREATE INDEX ix_notify_watches_account_id ON notify_watches (account_id);
CREATE INDEX ix_notify_edits_last_at ON notify_edits (last_at);
CREATE INDEX ix_vault_pending_account_id ON vault_pending (account_id);
CREATE INDEX ix_nextasks_links_note_id ON nextasks_links (note_id);
CREATE INDEX ix_nextasks_links_account_id ON nextasks_links (account_id);
COMMIT;
