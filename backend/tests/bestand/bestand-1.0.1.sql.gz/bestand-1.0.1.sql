BEGIN TRANSACTION;
CREATE TABLE accounts (
	id INTEGER NOT NULL, 
	name VARCHAR(64) NOT NULL, 
	display_name VARCHAR(80) NOT NULL, 
	whats_new_seen VARCHAR(32) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	sign_in VARCHAR(16) NOT NULL, 
	password_hash VARCHAR(255) NOT NULL, 
	password_changed_at DATETIME, 
	email VARCHAR(255) NOT NULL, 
	email_source VARCHAR(16) DEFAULT '' NOT NULL, 
	provider_email VARCHAR(255) DEFAULT '' NOT NULL, 
	provider_email_off VARCHAR(255) DEFAULT '' NOT NULL, 
	language VARCHAR(16) NOT NULL, 
	browser_language VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_seen_at DATETIME, 
	failed_logins INTEGER NOT NULL, 
	locked_until DATETIME, 
	blocked_at DATETIME, 
	deleted_at DATETIME, 
	password_reset_notice BOOLEAN DEFAULT 0 NOT NULL, 
	storage_limit INTEGER, 
	totp_secret_enc TEXT NOT NULL, 
	totp_recovery TEXT NOT NULL, 
	totp_last_step INTEGER NOT NULL, 
	avatar BLOB, 
	avatar_at DATETIME, 
	preferences JSON, 
	device_key VARCHAR(64) NOT NULL, 
	sync_seq INTEGER DEFAULT '0' NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (name)
);
INSERT INTO "accounts" VALUES(1,'betrieb','Betrieb Beispiel','1.0.1','operator','password','$argon2id$v=19$m=1024,t=1,p=1$SxhELirQyMKwZwZ/jl9ASQ$7KJir9VBLrVDbthbMh7ndGdXGTIHwhvyj/vdvlQWQ5w','2026-11-24 23:51:53.460656','betrieb@example.com','','','','de','','2026-11-24 23:51:53.461814','2026-11-24 23:51:55.164495',0,NULL,NULL,NULL,0,NULL,'01ff0e110c1ec80e510dbf9f3b80f0004bcc27472ff65441c2461de6a058e569f4750b06281e3a8d096c19381660fe6517e863bb65729952cd731e23','["e040b90f1e0f5c706886877aa3abb811d78a0fed0aa381fe13952b4c77cfe777", "381c34dec6252f79f06ea8273d17c4a85a2e6c0aa595192f48907ddc7a4ec97e", "225ab459f55927a79fcc600d3058e82eecad2cffdcc18e61a5f22f98164eda50", "2a5e403781cdb5812b9ed9586433420a055d672589e66ab4ea80e4a6da81f367", "2a4c4f2d20dc84e7e03149166c3883a75a2048d3697adce34271df46602790a5", "379af3e21e6d14548174f1609f3d8e32b6a8f721b8f93c26bc3930f0305f3062", "f871a43f9ff4bcdbf3f27dae62397746bee942cefe6a1c4c56bc20eb7931e545", "5a2c02e3e6f198429ff62e8c1ad828fc634068421bb29a1eb1b84deb38156c1f"]',59852143,NULL,NULL,NULL,'RsAIHRihVTMOp1iAdV7Y_tUH3nFuHECr',0);
INSERT INTO "accounts" VALUES(2,'erika-muster','Erika Muster','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$Utbv2BuEDVBII12GnLREhg$pArLV+YKXDEUq/hbyxaftVXcfc83xnn6F/P56Zeh3O8','2026-11-24 23:51:53.717205','','','','','','','2026-11-24 23:51:53.717530','2026-11-24 23:51:53.722435',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'K7SZ-odZm8oVaEUPE1tBhIOfTluKyWwn',0);
INSERT INTO "accounts" VALUES(3,'jonas','Jonas Beispiel','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$ZWOdo3NiR9dMbgOlYhidNQ$FYFCuNwcykRxoStqC+MmAhfxtmYR5nsZkPqqWtCrx8s','2026-11-24 23:51:53.801023','jonas@example.net','','','','','','2026-11-24 23:51:53.801349','2026-11-24 23:51:53.805613',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'2ckx11s279qTd_DFB7u-LfdqKF8BWbjD',0);
INSERT INTO "accounts" VALUES(4,'kim','Kim','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$8OT7pzMgS4deQ/XiyTMhzg$GLkpc5988FAfRi3HKV7CjG2IBNiIR3Ebf5dQTKnNx7M','2026-11-24 23:51:54.013630','familie@example.net','','','','','','2026-11-24 23:51:54.013937','2026-11-24 23:51:54.018457',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'JZwcNqPxKuoMowY8MR6qgWFJgtpMxXRn',0);
INSERT INTO "accounts" VALUES(5,'lou','Lou','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$vIhcZXviWiUbVwfqzZ3Jcw$z+wK3kboLgj1Gmfft7jMucsBMfluwQm06mczS/OSbR0','2026-11-24 23:51:54.063178','Familie@Example.net','','','','','','2026-11-24 23:51:54.063482','2026-11-24 23:51:54.068348',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'dryVYTWVvyH22aqpDOiwMIK0EpAF5Ixj',0);
INSERT INTO "accounts" VALUES(6,'mona','Mona Beispiel','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$biV6JR6BkemHtneCswDMOw$YmGgewuieN8Wcc0krOV64R3G3lQBescs2OudeHj+6Oo','2026-11-24 23:51:54.154557','mona@example.com','','','','','','2026-11-24 23:51:54.155146','2026-11-24 23:51:54.216226',0,NULL,NULL,NULL,0,NULL,'bf24ee682fc7f21799dea3a00f5343f83a76cad310d2edb81f3f2d8a0913b6c98458e2751f20e2e874fe8c3cbbd9b20683901e5e4591eeecfb132468','["91503f89b9a82e4c4c2dd5e14b70d9698529b148052db310d6dc513803f4e030", "52fcd1c9b617d04b46a992a0fe60ee6aa8365fff9037b7277ff6f461c82d61fc", "c27df958ff66399116260b6f53cf835077230f2a9036932ec7494094354e17dc", "0ad944c86a387c84c69a42105d24b4516494ac6fb0f64160702ad8240f194516", "88d0b34c8c162d779531f81303be88bef29b09d651dbc916899f90e887b3536a", "109b3e8a5709083ea56791e3bdebd683e9ad6f5513286b37e758cdd311395d8b", "56b05e6e3d808069d5819c4007b5ac852da161f72ea72449b8593260662c7d8b", "e4cbb082bc1c891ce0212309607e2700c1bfb7dcbd360de97d3e15a0ef91cb86"]',59852143,X'52494646D60000005745425056503820CA000000B011009D012A000100013E5128924723A2A1A1202800700A09696EE176A9701F800000787F7DE68F25F7FF6F7DE02A0592ED78B9390F7DB2721EFB64E43DF6C9C87BED9390F7DB2721EFB64E43DF6C9C87BED9390F7DB2721EFB64E43DF6C9C87BED9390F7DB2721EFB64E43DF6C9C87BED9390F7DB2721EFB64E43DF6C9C87BED9390F7DB2721EFB64E43DF6C9C87BED9390F7DAB0000FEF9CFFFFFD187F0C3F861FDF4BFFFF33461249BBA9DE05A8282828282828282828282814DF050000000000000000000000000','2026-11-24 23:51:54.363203',NULL,'09vKI8pcGfvh3wh8hsd73-9KuomWhTXp',9);
INSERT INTO "accounts" VALUES(7,'sam','Sam','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$S1IwUAKtoERwhyg1hjn7PQ$KwgoBrxULLoHsePxPORtV7KGxfhZESeui5XPRPnvgIY','2026-11-24 23:51:54.498625','sam@example.org','provider','','','','','2026-11-24 23:51:54.498935','2026-11-24 23:51:54.523941',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'C-x0flHp26gBJIGvCHIgAOyftzlVLUvd',0);
INSERT INTO "accounts" VALUES(8,'robin.sso','','1.0.1','operator','oidc','',NULL,'robin@sso.example.com','provider','','','','','2026-11-24 23:51:54.810132','2026-11-24 23:51:54.825324',0,NULL,NULL,NULL,0,NULL,'','',0,NULL,NULL,NULL,'U-InMHgmqol8uMJA-1D4cs-u_A1Kez_K',0);
INSERT INTO "accounts" VALUES(9,'gesperrt','Gesperrt Beispiel','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$Vaf5VL6m88FHZgehXRYUZQ$FQChNnsWfDdlHUY2ZiysFvMJbEqy1iLIp02FyyazfyM','2026-11-24 23:51:54.887011','gesperrt@example.com','','','','','','2026-11-24 23:51:54.887553','2026-11-24 23:51:54.892616',0,NULL,'2026-11-24 23:51:55.050352',NULL,0,NULL,'','',0,NULL,NULL,NULL,'YkirhSct57G6u2EpkcEnD9uanV8v266D',0);
INSERT INTO "accounts" VALUES(10,'weg','Weg Beispiel','1.0.1','member','password','$argon2id$v=19$m=1024,t=1,p=1$jC2G2rb4R8xxfvmtIXNz8g$Qh8qKx7OZeWToddpV5YA7ooY6oHF4KvsbrcAGl3UGKM','2026-11-24 23:51:54.981267','weg@example.com','','','','','','2026-11-24 23:51:54.982456','2026-11-24 23:51:54.990915',0,NULL,NULL,'2026-11-24 23:51:55.096904',0,NULL,'','',0,NULL,NULL,NULL,'5NPtKVOQwJkbJlJgFL_9J3IP5DFE3M_w',0);
CREATE TABLE api_refs (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	external_ref VARCHAR(200) NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_api_refs_account_ref UNIQUE (account_id, external_ref), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE DEFERRABLE INITIALLY DEFERRED
);
CREATE TABLE api_tokens (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	kind VARCHAR(16) NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	level VARCHAR(8) NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	prefix VARCHAR(16) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	expires_at DATETIME, 
	client_id VARCHAR(64), 
	refresh_hash VARCHAR(64), 
	refresh_old_hash VARCHAR(64), 
	signed_in_at DATETIME, 
	allow_mcp BOOLEAN, 
	folder_ids JSON, 
	blocked_at DATETIME, 
	device_kind VARCHAR(8) DEFAULT '' NOT NULL, 
	via_token_id INTEGER, 
	full_cursor INTEGER, 
	full_start INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
INSERT INTO "api_tokens" VALUES(1,3,'api','Dashboard','read','74a550df77b49596cb47a292166cbc961f1dce9cc970a4e02f1a6c9cb2d8913b','nn_api_best','2026-11-24 23:51:53.972361',NULL,NULL,NULL,NULL,NULL,NULL,0,'null',NULL,'',NULL,NULL,NULL);
INSERT INTO "api_tokens" VALUES(2,6,'device','iPhone (Bestand)','write','d33e033790d23d9a4deca35c0ffe67b8f9191f05df864719e1465d3b5e9f0944','nnd_best','2026-11-24 23:51:54.445438',NULL,NULL,NULL,NULL,NULL,NULL,0,'null',NULL,'ios',NULL,NULL,NULL);
CREATE TABLE app_codes (
	code_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	state VARCHAR(128) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	PRIMARY KEY (code_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE app_counter (
	id INTEGER NOT NULL, 
	value INTEGER NOT NULL, 
	floor INTEGER NOT NULL, 
	PRIMARY KEY (id)
);
INSERT INTO "app_counter" VALUES(1,13,0);
CREATE TABLE app_gone_devices (
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (token_hash)
);
CREATE TABLE app_pairings (
	id VARCHAR(32) NOT NULL, 
	account_id INTEGER NOT NULL, 
	secret_hash VARCHAR(64) NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	used_at DATETIME, 
	device_token_id INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(device_token_id) REFERENCES api_tokens (id) ON DELETE SET NULL
);
INSERT INTO "app_pairings" VALUES('bestand-kopplung-mona-20',6,'5de22afd532d67117d3eaf0466acfd924008f8bb6104b87d5373065f292c43ad','2026-11-24 23:51:54.396078','2026-11-25 00:01:54.396078','2026-11-24 23:51:54.438110',2);
CREATE TABLE app_tombstones (
	id INTEGER NOT NULL, 
	seq INTEGER NOT NULL, 
	kind VARCHAR(8) NOT NULL, 
	object_id VARCHAR(36) NOT NULL, 
	account_id INTEGER, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE TABLE attachment_mentions (
	note_id VARCHAR(36) NOT NULL, 
	attachment_id VARCHAR(32) NOT NULL, 
	vouched BOOLEAN DEFAULT 1 NOT NULL, 
	PRIMARY KEY (note_id, attachment_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE attachment_ocr (
	attachment_id VARCHAR(32) NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	pages INTEGER NOT NULL, 
	languages VARCHAR(64) NOT NULL, 
	source VARCHAR(16) NOT NULL, 
	error VARCHAR(32) NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (attachment_id), 
	FOREIGN KEY(attachment_id) REFERENCES attachments (id) ON DELETE CASCADE
);
CREATE TABLE attachment_refs (
	note_id VARCHAR(36) NOT NULL, 
	attachment_id VARCHAR(32) NOT NULL, 
	position INTEGER NOT NULL, 
	PRIMARY KEY (note_id, attachment_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE attachment_texts (
	attachment_id VARCHAR(32) NOT NULL, 
	page INTEGER NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	text TEXT NOT NULL, 
	language VARCHAR(8) NOT NULL, 
	source VARCHAR(16) NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (attachment_id, page), 
	FOREIGN KEY(attachment_id) REFERENCES attachments (id) ON DELETE CASCADE
);
CREATE TABLE attachments (
	id VARCHAR(32) NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	owner_id INTEGER NOT NULL, 
	uploaded_by INTEGER, 
	kind VARCHAR(16) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	mime VARCHAR(100) NOT NULL, 
	size INTEGER NOT NULL, 
	stored INTEGER NOT NULL, 
	width INTEGER, 
	height INTEGER, 
	pages INTEGER, 
	duration_ms INTEGER, 
	has_view BOOLEAN NOT NULL, 
	has_thumb BOOLEAN NOT NULL, 
	inline BOOLEAN NOT NULL, 
	preview_failed BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	unref_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(uploaded_by) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE auth_sessions (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	last_seen_at DATETIME NOT NULL, 
	ip VARCHAR(64) NOT NULL, 
	user_agent VARCHAR(255) NOT NULL, 
	provider_checked BOOLEAN DEFAULT 0 NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "auth_sessions" VALUES(1,'b422c14c9ef3e4681ba443b1a39312b292af87fa08337d91d44302ab157949e9',1,'2026-11-24 23:51:53.481668','2026-12-24 23:51:53.476670','2026-11-24 23:51:53.481671','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(2,'367c590bb0c34f6af42b4dd52f1fdded0b747d12de544bd6459f63f6349138c5',2,'2026-11-24 23:51:53.725370','2026-12-24 23:51:53.722031','2026-11-24 23:51:53.725374','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(3,'fcf32653b0288d2ea7a8aa2be37d3bac1cc8d3c2b082f7cbb93f96c6f2e95bf3',3,'2026-11-24 23:51:53.808683','2026-12-24 23:51:53.805426','2026-11-24 23:51:53.808686','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(4,'2dfceabe532c5297863167a4eb4b7616bd4ef6fc325725b845ed4d7292fd74fe',4,'2026-11-24 23:51:54.021703','2026-12-24 23:51:54.018282','2026-11-24 23:51:54.021705','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(5,'28333cd9947439ddca3b18c9d2a841fb085c4ff34b53609f017d9ac9425e1499',5,'2026-11-24 23:51:54.072013','2026-12-24 23:51:54.068281','2026-11-24 23:51:54.072016','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(6,'3d97ea6c1a17b659653008ab65132982f56d9d1ce2f4ba01994862a53b58199c',6,'2026-11-24 23:51:54.166447','2026-12-24 23:51:54.161765','2026-11-24 23:51:54.166452','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(7,'aad3058973b615e8dd96c7c54756705d681a7a295db2830ed0f09bf050ec2ffd',7,'2026-11-24 23:51:54.506203','2026-12-24 23:51:54.503326','2026-11-24 23:51:54.506205','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(8,'633798dfb33f61ae7bc34c0ec50ff5327b8659f0287ac50b10be01801fec59bf',8,'2026-11-24 23:51:54.825748','2026-12-24 23:51:54.825250','2026-11-24 23:51:54.825750','testclient','testclient',1);
INSERT INTO "auth_sessions" VALUES(9,'abf98af92aac081b69123da5fc0d45c28c71e7c9031e39140ad7a0d2d6049675',9,'2026-11-24 23:51:54.895059','2026-12-24 23:51:54.892549','2026-11-24 23:51:54.895061','testclient','testclient',0);
INSERT INTO "auth_sessions" VALUES(10,'943798215047e60f07228ba3c770ed23590cab5353b755646d49aabedf44da31',10,'2026-11-24 23:51:54.997153','2026-12-24 23:51:54.990718','2026-11-24 23:51:54.997161','testclient','testclient',0);
CREATE TABLE export_jobs (
	id VARCHAR(36) NOT NULL, 
	account_id INTEGER NOT NULL, 
	folder_id VARCHAR(36), 
	label VARCHAR(200) NOT NULL, 
	filename VARCHAR(255) NOT NULL, 
	status VARCHAR(16) NOT NULL, 
	problem VARCHAR(32) NOT NULL, 
	estimate INTEGER NOT NULL, 
	size INTEGER NOT NULL, 
	notes INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	started_at DATETIME, 
	finished_at DATETIME, 
	expires_at DATETIME, 
	seen BOOLEAN DEFAULT 0 NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE folders (
	id VARCHAR(36) NOT NULL, 
	owner_id INTEGER NOT NULL, 
	parent_id VARCHAR(36), 
	kind VARCHAR(16) NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	icon VARCHAR(32) NOT NULL, 
	color VARCHAR(16) NOT NULL, 
	position INTEGER, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	deleted_at DATETIME, 
	deleted_batch VARCHAR(36), 
	sync_seq INTEGER DEFAULT '0' NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(parent_id) REFERENCES folders (id) ON DELETE CASCADE
);
CREATE TABLE invites (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	role VARCHAR(16) NOT NULL, 
	email VARCHAR(255) NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(created_by) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "invites" VALUES(1,'e0cd71b6fa0ba0cd36b5477861481ff772561fd8429e50e2735cb82ffddb9489','member','gast@example.org',1,'2026-11-24 23:51:55.134769','2026-12-24 23:51:55.134414');
CREATE TABLE nextasks_connections (
	account_id INTEGER NOT NULL, 
	url VARCHAR(500) NOT NULL, 
	token_enc VARCHAR(2000) NOT NULL, 
	name VARCHAR(200) NOT NULL, 
	checked_at DATETIME NOT NULL, 
	last_list_id VARCHAR(100) NOT NULL, 
	last_list_name VARCHAR(300) NOT NULL, 
	device_id INTEGER, 
	task_choice TEXT DEFAULT '' NOT NULL, 
	default_list_id VARCHAR(100) DEFAULT '' NOT NULL, 
	PRIMARY KEY (account_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE nextasks_links (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	request_id VARCHAR(64) NOT NULL, 
	position INTEGER NOT NULL, 
	anchor VARCHAR(64) NOT NULL, 
	task_id VARCHAR(100) NOT NULL, 
	task_url VARCHAR(2000) NOT NULL, 
	list_name VARCHAR(300) NOT NULL, 
	due_date DATE, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	CONSTRAINT uq_nextasks_link_request UNIQUE (account_id, request_id, position), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE note_edits (
	note_id VARCHAR(36) NOT NULL, 
	writer VARCHAR(160) NOT NULL, 
	account_id INTEGER, 
	via VARCHAR(140) NOT NULL, 
	first_at DATETIME NOT NULL, 
	last_at DATETIME NOT NULL, 
	PRIMARY KEY (note_id, writer), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE note_list_views (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	"key" VARCHAR(40) NOT NULL, 
	mode VARCHAR(8) NOT NULL, 
	sort VARCHAR(8) NOT NULL, 
	direction VARCHAR(4) NOT NULL, 
	grouped BOOLEAN NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, "key"), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE note_tags (
	note_id VARCHAR(36) NOT NULL, 
	label VARCHAR(64) NOT NULL, 
	"key" VARCHAR(200) NOT NULL, 
	count INTEGER NOT NULL, 
	PRIMARY KEY (note_id, label), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE note_updates (
	id INTEGER NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	"update" BLOB NOT NULL, 
	account_id INTEGER, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE note_versions (
	id INTEGER NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	created_at DATETIME NOT NULL, 
	started_at DATETIME NOT NULL, 
	state BLOB NOT NULL, 
	title VARCHAR(120) NOT NULL, 
	size INTEGER NOT NULL, 
	authors JSON NOT NULL, 
	restored_from DATETIME, 
	sealed BOOLEAN DEFAULT 0 NOT NULL, 
	sealed_rev INTEGER, 
	PRIMARY KEY (id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE notes (
	id VARCHAR(36) NOT NULL, 
	owner_id INTEGER NOT NULL, 
	folder_id VARCHAR(36) NOT NULL, 
	title VARCHAR(120) NOT NULL, 
	title_check BOOLEAN DEFAULT 0 NOT NULL, 
	origin VARCHAR(100) NOT NULL, 
	copied_from VARCHAR(80) DEFAULT '' NOT NULL, 
	ydoc BLOB NOT NULL, 
	text TEXT NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	updated_by_id INTEGER, 
	deleted_at DATETIME, 
	deleted_batch VARCHAR(36), 
	deleted_by_id INTEGER, 
	pinned_at DATETIME, 
	color VARCHAR(16) DEFAULT '' NOT NULL, 
	tasks_done INTEGER, 
	tasks_total INTEGER, 
	listed_at DATETIME, 
	paper VARCHAR(8) DEFAULT 'blank' NOT NULL, 
	icon VARCHAR(32) DEFAULT '' NOT NULL, 
	locked BOOLEAN DEFAULT 0 NOT NULL, 
	sync_seq INTEGER DEFAULT '0' NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(folder_id) REFERENCES folders (id) ON DELETE CASCADE, 
	FOREIGN KEY(updated_by_id) REFERENCES accounts (id) ON DELETE SET NULL, 
	FOREIGN KEY(deleted_by_id) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE notify_baselines (
	note_id VARCHAR(36) NOT NULL, 
	lines JSON NOT NULL, 
	taken_at DATETIME NOT NULL, 
	trashed_by INTEGER, 
	PRIMARY KEY (note_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(trashed_by) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE notify_edits (
	note_id VARCHAR(36) NOT NULL, 
	account_id INTEGER NOT NULL, 
	first_at DATETIME NOT NULL, 
	last_at DATETIME NOT NULL, 
	PRIMARY KEY (note_id, account_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE notify_outbox (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	channel VARCHAR(8) NOT NULL, 
	target_id INTEGER NOT NULL, 
	payload JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	next_try_at DATETIME NOT NULL, 
	attempts INTEGER NOT NULL, 
	sent_at DATETIME, 
	failed_at DATETIME, 
	last_error VARCHAR(40) NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE notify_watches (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	note_id VARCHAR(36), 
	folder_id VARCHAR(36), 
	"on" BOOLEAN NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, note_id), 
	UNIQUE (account_id, folder_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(folder_id) REFERENCES folders (id) ON DELETE CASCADE
);
CREATE TABLE oauth_clients (
	id VARCHAR(64) NOT NULL, 
	name VARCHAR(100) NOT NULL, 
	redirect_uris JSON NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id)
);
CREATE TABLE oauth_codes (
	code_hash VARCHAR(64) NOT NULL, 
	client_id VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	redirect_uri VARCHAR(2048) NOT NULL, 
	challenge VARCHAR(128) NOT NULL, 
	level VARCHAR(8) NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (code_hash), 
	FOREIGN KEY(client_id) REFERENCES oauth_clients (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE oauth_spent (
	token_hash VARCHAR(64) NOT NULL, 
	key_id INTEGER NOT NULL, 
	spent_at DATETIME NOT NULL, 
	PRIMARY KEY (token_hash), 
	FOREIGN KEY(key_id) REFERENCES api_tokens (id) ON DELETE CASCADE
);
CREATE TABLE oidc_links (
	id INTEGER NOT NULL, 
	provider_id INTEGER NOT NULL, 
	subject VARCHAR(255) NOT NULL, 
	account_id INTEGER NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	email VARCHAR(320), 
	created_at DATETIME NOT NULL, 
	last_used_at DATETIME, 
	PRIMARY KEY (id), 
	UNIQUE (provider_id, subject), 
	UNIQUE (provider_id, account_id), 
	FOREIGN KEY(provider_id) REFERENCES oidc_providers (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "oidc_links" VALUES(1,1,'bestand-sam',7,'https://sso.example.com','sam@example.org','2026-11-24 23:51:54.622288',NULL);
INSERT INTO "oidc_links" VALUES(2,1,'bestand-robin',8,'https://sso.example.com','robin@sso.example.com','2026-11-24 23:51:54.814216',NULL);
CREATE TABLE oidc_providers (
	id INTEGER NOT NULL, 
	slug VARCHAR(40) NOT NULL, 
	label VARCHAR(64) NOT NULL, 
	issuer VARCHAR(500) NOT NULL, 
	client_id VARCHAR(255) NOT NULL, 
	client_secret_enc TEXT NOT NULL, 
	scopes VARCHAR(500) NOT NULL, 
	enabled BOOLEAN NOT NULL, 
	auto_create BOOLEAN NOT NULL, 
	trusts_second_factor BOOLEAN NOT NULL, 
	managed VARCHAR(20) NOT NULL, 
	position INTEGER NOT NULL, 
	redirect_path VARCHAR(300) NOT NULL, 
	registered_redirect VARCHAR(500) DEFAULT '' NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (slug)
);
INSERT INTO "oidc_providers" VALUES(1,'sso','SSO','https://sso.example.com','nexnotes-bestand','bfa8cb1dc4aa163ebac84018065f19b402975531b565d1c2ebcf44092010327dbb36b44476135f70be78','openid profile email',1,0,1,'',0,'','','2026-11-24 23:51:53.668905');
CREATE TABLE password_resets (
	id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	account_id INTEGER NOT NULL, 
	created_by INTEGER, 
	created_at DATETIME NOT NULL, 
	expires_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (token_hash), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(created_by) REFERENCES accounts (id) ON DELETE SET NULL
);
INSERT INTO "password_resets" VALUES(1,'aba2148f307ba899f3a0c389145ce9c1f22308feccf976156e104183529183be',2,1,'2026-11-24 23:51:55.173118','2026-12-24 23:51:55.172259');
CREATE TABLE push_devices (
	token_id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	ticket TEXT NOT NULL, 
	"key" VARCHAR(64) NOT NULL, 
	updated_at DATETIME NOT NULL, 
	last_ok_at DATETIME, 
	PRIMARY KEY (token_id), 
	FOREIGN KEY(token_id) REFERENCES api_tokens (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE read_links (
	id INTEGER NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	owner_id INTEGER NOT NULL, 
	token_hash VARCHAR(64) NOT NULL, 
	expires_on VARCHAR(10) NOT NULL, 
	expires_at DATETIME NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (note_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	UNIQUE (token_hash)
);
CREATE TABLE sealed_notes (
	note_id VARCHAR(36) NOT NULL, 
	content BLOB NOT NULL, 
	rev INTEGER NOT NULL, 
	saved_at DATETIME NOT NULL, 
	saved_by_id INTEGER, 
	PRIMARY KEY (note_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(saved_by_id) REFERENCES accounts (id) ON DELETE SET NULL
);
CREATE TABLE settings (
	"key" VARCHAR(64) NOT NULL, 
	value JSON, 
	PRIMARY KEY ("key")
);
INSERT INTO "settings" VALUES('running_version','"1.0.1"');
INSERT INTO "settings" VALUES('tags_rules','"1"');
INSERT INTO "settings" VALUES('webpush_key_enc','"ae04d927e03206fb518e5bb82efa18a2d497b3fe59526a3989cd9b9c6790c3254ab7dedda155ffd5eb3a7a8645223c9f9f99184232291a9de557d7a1dc9c19741aada7fd6078d87380fc45182afbeb25ebe12bbcf7eb607f434dca2d4438ceace48e3d16f6408ae7046782b42cde078c6f714dc76ba44efd3915581f6b395a48dad927f7081f11d0144ca473a072604c619b88a42be10415956487b54d0e05401fdc6b595e8a778f9f04e1b0dec8c01d024e176e0c06f2d63b533900e5de1f277c4a5e542e3ef0a60e09f9a5e73069f92eba2e7537757636db26bf3ff1dca7fcc99218bfaff77949433858a50f4e767a67bef93c1aacd2bd336105d9baabd440a421e009e0196cb8eeb862cd65"');
INSERT INTO "settings" VALUES('smart_folders_seeded','true');
INSERT INTO "settings" VALUES('smart_folders_seeded_places','true');
INSERT INTO "settings" VALUES('smart_folders_seeded_icons','true');
INSERT INTO "settings" VALUES('smart_folders_seeded_keys','true');
INSERT INTO "settings" VALUES('guide_seeded','true');
INSERT INTO "settings" VALUES('public_url','"https://notes.example.com"');
INSERT INTO "settings" VALUES('smtp_host','"smtp.example.com"');
INSERT INTO "settings" VALUES('smtp_port',465);
INSERT INTO "settings" VALUES('smtp_security','"tls"');
INSERT INTO "settings" VALUES('smtp_user','"notes@example.com"');
INSERT INTO "settings" VALUES('smtp_password_enc','"c16daafd611d651e13df7ae22e4197349aa74f9ba68b853aa7f4673cbe44cb22ff845032531c3675ee029d"');
INSERT INTO "settings" VALUES('smtp_from','"notes@example.com"');
CREATE TABLE share_notices (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	reason VARCHAR(16) NOT NULL, 
	kind VARCHAR(8) NOT NULL, 
	title VARCHAR(120) NOT NULL, 
	owner_name VARCHAR(80) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE share_pins (
	account_id INTEGER NOT NULL, 
	note_id VARCHAR(36) NOT NULL, 
	pinned_at DATETIME NOT NULL, 
	PRIMARY KEY (account_id, note_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE
);
CREATE TABLE shares (
	id INTEGER NOT NULL, 
	owner_id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	note_id VARCHAR(36), 
	folder_id VARCHAR(36), 
	level VARCHAR(8) NOT NULL, 
	created_at DATETIME NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (account_id, note_id), 
	UNIQUE (account_id, folder_id), 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(folder_id) REFERENCES folders (id) ON DELETE CASCADE
);
CREATE TABLE smart_folders (
	id VARCHAR(36) NOT NULL, 
	owner_id INTEGER NOT NULL, 
	name VARCHAR(60) NOT NULL, 
	name_key VARCHAR(200) NOT NULL, 
	preset VARCHAR(16) NOT NULL, 
	"match" VARCHAR(8) NOT NULL, 
	conditions JSON NOT NULL, 
	icon VARCHAR(32) DEFAULT 'filter' NOT NULL, 
	color VARCHAR(16) DEFAULT '' NOT NULL, 
	position INTEGER NOT NULL, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	sync_seq INTEGER DEFAULT '0' NOT NULL, 
	PRIMARY KEY (id), 
	UNIQUE (owner_id, name_key), 
	FOREIGN KEY(owner_id) REFERENCES accounts (id) ON DELETE CASCADE
);
INSERT INTO "smart_folders" VALUES('b5986ec1-6989-4d15-af0e-ee9a599b11bb',1,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 23:51:53.463130','2026-11-24 23:51:53.463130',3);
INSERT INTO "smart_folders" VALUES('2f9d2d73-561c-458a-9632-4a6aa788a7e1',1,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 23:51:53.463130','2026-11-24 23:51:53.463130',3);
INSERT INTO "smart_folders" VALUES('f080f6a4-f2de-4052-957f-6a92bcf146c2',1,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 23:51:53.463130','2026-11-24 23:51:53.463130',3);
INSERT INTO "smart_folders" VALUES('cd8d8226-6cdf-49a9-9c9d-96c3b8a8b4f1',2,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 23:51:53.718061','2026-11-24 23:51:53.718061',4);
INSERT INTO "smart_folders" VALUES('6d97afce-7d11-4f98-b47f-6a1eb8097432',2,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 23:51:53.718061','2026-11-24 23:51:53.718061',4);
INSERT INTO "smart_folders" VALUES('3b6b4ce6-ea2b-42d2-9c4a-ce8977359e82',2,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 23:51:53.718061','2026-11-24 23:51:53.718061',4);
INSERT INTO "smart_folders" VALUES('663291fe-2f53-49ed-864f-01b63acb7c69',3,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 23:51:53.801863','2026-11-24 23:51:53.801863',5);
INSERT INTO "smart_folders" VALUES('521ca391-9cf4-4005-b12f-cabc824d0344',3,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 23:51:53.801863','2026-11-24 23:51:53.801863',5);
INSERT INTO "smart_folders" VALUES('257e7243-9d8b-4802-9ead-baaa6d681073',3,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 23:51:53.801863','2026-11-24 23:51:53.801863',5);
INSERT INTO "smart_folders" VALUES('688fe6ed-2684-40be-85cc-82a44606e039',4,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 23:51:54.014495','2026-11-24 23:51:54.014495',6);
INSERT INTO "smart_folders" VALUES('67d9c59e-107e-4853-afb4-44447d0a6ec7',4,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 23:51:54.014495','2026-11-24 23:51:54.014495',6);
INSERT INTO "smart_folders" VALUES('eefd3469-329d-4658-a8d5-cb475966e866',4,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 23:51:54.014495','2026-11-24 23:51:54.014495',6);
INSERT INTO "smart_folders" VALUES('ed05be3e-5ff1-4b08-8bc7-b2b7917a46c5',5,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 23:51:54.063990','2026-11-24 23:51:54.063990',7);
INSERT INTO "smart_folders" VALUES('e9ca3788-ae24-4ff3-a0ca-faccb9d6e3c3',5,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 23:51:54.063990','2026-11-24 23:51:54.063990',7);
INSERT INTO "smart_folders" VALUES('95d6549f-7620-4c43-9aff-592dd4d50bd2',5,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 23:51:54.063990','2026-11-24 23:51:54.063990',7);
INSERT INTO "smart_folders" VALUES('616d859f-c184-45b7-8fe2-cf239b7297bd',6,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 23:51:54.156199','2026-11-24 23:51:54.156199',8);
INSERT INTO "smart_folders" VALUES('cbda7691-8d97-4868-b6e6-b65186ae2dbc',6,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 23:51:54.156199','2026-11-24 23:51:54.156199',8);
INSERT INTO "smart_folders" VALUES('802ae5e3-5b0d-4a26-925b-19feafee9ee1',6,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 23:51:54.156199','2026-11-24 23:51:54.156199',8);
INSERT INTO "smart_folders" VALUES('cca75f0a-cfcc-464c-b9fe-89abd5213daf',7,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 23:51:54.499466','2026-11-24 23:51:54.499466',10);
INSERT INTO "smart_folders" VALUES('cbf9a79d-6270-4b36-8834-15b40fd7e146',7,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 23:51:54.499466','2026-11-24 23:51:54.499466',10);
INSERT INTO "smart_folders" VALUES('04b61ef6-8971-405e-8444-9ab126249c16',7,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 23:51:54.499466','2026-11-24 23:51:54.499466',10);
INSERT INTO "smart_folders" VALUES('9e5c2a41-6e60-4054-bd08-77f69e06b6d3',8,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 23:51:54.811082','2026-11-24 23:51:54.811082',11);
INSERT INTO "smart_folders" VALUES('6d43e227-ba2f-472b-8d02-3f728bbeae99',8,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 23:51:54.811082','2026-11-24 23:51:54.811082',11);
INSERT INTO "smart_folders" VALUES('8b7cf469-73a8-4e49-a404-c7135890e8d9',8,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 23:51:54.811082','2026-11-24 23:51:54.811082',11);
INSERT INTO "smart_folders" VALUES('23f1db20-6596-4d92-ba67-63f4dc6550e3',9,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 23:51:54.888087','2026-11-24 23:51:54.888087',12);
INSERT INTO "smart_folders" VALUES('235a3935-da68-4c47-939c-006fbd2988ab',9,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 23:51:54.888087','2026-11-24 23:51:54.888087',12);
INSERT INTO "smart_folders" VALUES('d523671a-c1f4-4c89-932a-b64f62ebc2af',9,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 23:51:54.888087','2026-11-24 23:51:54.888087',12);
INSERT INTO "smart_folders" VALUES('5d4c4cfa-a350-4433-813a-2bd59558b1af',10,'','preset:open_tasks','open_tasks','all','[{"kind": "tasks", "op": "open"}]','filter','',0,'2026-11-24 23:51:54.983963','2026-11-24 23:51:54.983963',13);
INSERT INTO "smart_folders" VALUES('b3105b24-75a9-4410-95db-d188802c8ac2',10,'','preset:recent','recent','all','[{"kind": "date", "field": "updated", "period": "week"}]','filter','',1,'2026-11-24 23:51:54.983963','2026-11-24 23:51:54.983963',13);
INSERT INTO "smart_folders" VALUES('382ec438-1bb5-48d9-82d5-1e62abc1f44c',10,'','preset:attachments','attachments','all','[{"kind": "attachment", "type": "any"}]','paperclip','',2,'2026-11-24 23:51:54.983963','2026-11-24 23:51:54.983963',13);
CREATE TABLE vault_pending (
	note_id VARCHAR(36) NOT NULL, 
	account_id INTEGER NOT NULL, 
	step VARCHAR(8) NOT NULL, 
	parts JSON NOT NULL, 
	started_at DATETIME NOT NULL, 
	PRIMARY KEY (note_id), 
	FOREIGN KEY(note_id) REFERENCES notes (id) ON DELETE CASCADE, 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE vaults (
	account_id INTEGER NOT NULL, 
	kdf JSON NOT NULL, 
	wrapped_key BLOB NOT NULL, 
	auth_hash VARCHAR(64) NOT NULL, 
	epoch INTEGER NOT NULL, 
	failures INTEGER NOT NULL, 
	rounds INTEGER NOT NULL, 
	wait_until DATETIME, 
	created_at DATETIME NOT NULL, 
	changed_at DATETIME NOT NULL, 
	PRIMARY KEY (account_id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE
);
CREATE TABLE webpush_subscriptions (
	id INTEGER NOT NULL, 
	account_id INTEGER NOT NULL, 
	session_id INTEGER NOT NULL, 
	endpoint TEXT NOT NULL, 
	p256dh VARCHAR(100) NOT NULL, 
	auth VARCHAR(40) NOT NULL, 
	user_agent VARCHAR(300) NOT NULL, 
	created_at DATETIME NOT NULL, 
	last_ok_at DATETIME, 
	PRIMARY KEY (id), 
	FOREIGN KEY(account_id) REFERENCES accounts (id) ON DELETE CASCADE, 
	FOREIGN KEY(session_id) REFERENCES auth_sessions (id) ON DELETE CASCADE, 
	UNIQUE (endpoint)
);
CREATE TABLE work_jobs (
	id INTEGER NOT NULL, 
	kind VARCHAR(32) NOT NULL, 
	ref VARCHAR(64) NOT NULL, 
	state VARCHAR(16) NOT NULL, 
	run_after DATETIME NOT NULL, 
	attempts INTEGER NOT NULL, 
	account_id INTEGER, 
	created_at DATETIME NOT NULL, 
	updated_at DATETIME NOT NULL, 
	PRIMARY KEY (id)
);
CREATE INDEX ix_work_jobs_account_id ON work_jobs (account_id);
CREATE UNIQUE INDEX ix_work_jobs_kind_ref ON work_jobs (kind, ref);
CREATE INDEX ix_work_jobs_turn ON work_jobs (state, run_after, id);
CREATE INDEX ix_app_tombstones_account_id ON app_tombstones (account_id);
CREATE INDEX ix_app_tombstones_created_at ON app_tombstones (created_at);
CREATE INDEX ix_app_tombstones_seq ON app_tombstones (seq);
CREATE INDEX ix_app_gone_devices_account_id ON app_gone_devices (account_id);
CREATE INDEX ix_auth_sessions_account_id ON auth_sessions (account_id);
CREATE INDEX ix_oidc_links_account_id ON oidc_links (account_id);
CREATE INDEX ix_oidc_links_provider_id ON oidc_links (provider_id);
CREATE INDEX ix_password_resets_account_id ON password_resets (account_id);
CREATE INDEX ix_api_tokens_client_id ON api_tokens (client_id);
CREATE INDEX ix_api_tokens_account_id ON api_tokens (account_id);
CREATE INDEX ix_api_tokens_refresh_hash ON api_tokens (refresh_hash);
CREATE INDEX ix_folders_deleted_batch ON folders (deleted_batch);
CREATE INDEX ix_folders_parent_id ON folders (parent_id);
CREATE INDEX ix_folders_owner_id ON folders (owner_id);
CREATE UNIQUE INDEX uq_folders_one_inbox ON folders (owner_id) WHERE kind = 'inbox';
CREATE INDEX ix_folders_deleted_at ON folders (deleted_at);
CREATE INDEX ix_folders_sync_seq ON folders (sync_seq);
CREATE INDEX ix_note_list_views_account_id ON note_list_views (account_id);
CREATE INDEX ix_share_notices_account_id ON share_notices (account_id);
CREATE INDEX ix_smart_folders_owner_id ON smart_folders (owner_id);
CREATE INDEX ix_smart_folders_sync_seq ON smart_folders (sync_seq);
CREATE INDEX ix_oauth_codes_account_id ON oauth_codes (account_id);
CREATE INDEX ix_oauth_codes_client_id ON oauth_codes (client_id);
CREATE INDEX ix_export_jobs_account_id ON export_jobs (account_id);
CREATE INDEX ix_export_jobs_status ON export_jobs (status);
CREATE INDEX ix_app_codes_account_id ON app_codes (account_id);
CREATE INDEX ix_notify_outbox_due ON notify_outbox (sent_at, failed_at, next_try_at);
CREATE INDEX ix_notify_outbox_account_id ON notify_outbox (account_id);
CREATE INDEX ix_notes_updated_at ON notes (updated_at);
CREATE INDEX ix_notes_locked ON notes (locked);
CREATE INDEX ix_notes_deleted_at ON notes (deleted_at);
CREATE INDEX ix_notes_folder_id ON notes (folder_id);
CREATE INDEX ix_notes_sync_seq ON notes (sync_seq);
CREATE INDEX ix_notes_owner_id ON notes (owner_id);
CREATE INDEX ix_notes_deleted_batch ON notes (deleted_batch);
CREATE INDEX ix_oauth_spent_key_id ON oauth_spent (key_id);
CREATE INDEX ix_app_pairings_account_id ON app_pairings (account_id);
CREATE INDEX ix_webpush_subscriptions_session_id ON webpush_subscriptions (session_id);
CREATE INDEX ix_webpush_subscriptions_account_id ON webpush_subscriptions (account_id);
CREATE INDEX ix_push_devices_account_id ON push_devices (account_id);
CREATE INDEX ix_note_updates_note_id ON note_updates (note_id);
CREATE INDEX ix_attachments_note_id ON attachments (note_id);
CREATE INDEX ix_attachments_unref_at ON attachments (unref_at);
CREATE INDEX ix_attachments_owner_created ON attachments (owner_id, created_at);
CREATE INDEX ix_attachments_owner_id ON attachments (owner_id);
CREATE INDEX ix_attachment_refs_attachment ON attachment_refs (attachment_id);
CREATE INDEX ix_attachment_mentions_attachment ON attachment_mentions (attachment_id);
CREATE INDEX ix_shares_owner_id ON shares (owner_id);
CREATE INDEX ix_shares_folder_id ON shares (folder_id);
CREATE INDEX ix_shares_account_id ON shares (account_id);
CREATE INDEX ix_shares_note_id ON shares (note_id);
CREATE INDEX ix_read_links_expires ON read_links (expires_at);
CREATE INDEX ix_read_links_owner_id ON read_links (owner_id);
CREATE INDEX ix_note_tags_key_note ON note_tags ("key", note_id);
CREATE INDEX ix_note_versions_note_created ON note_versions (note_id, created_at);
CREATE INDEX ix_note_versions_note_id ON note_versions (note_id);
CREATE INDEX ix_note_edits_last_at ON note_edits (last_at);
CREATE INDEX ix_api_refs_note_id ON api_refs (note_id);
CREATE INDEX ix_api_refs_account_id ON api_refs (account_id);
CREATE INDEX ix_notify_watches_note_id ON notify_watches (note_id);
CREATE INDEX ix_notify_watches_folder_id ON notify_watches (folder_id);
CREATE INDEX ix_notify_watches_account_id ON notify_watches (account_id);
CREATE INDEX ix_notify_edits_last_at ON notify_edits (last_at);
CREATE INDEX ix_vault_pending_account_id ON vault_pending (account_id);
CREATE INDEX ix_nextasks_links_account_id ON nextasks_links (account_id);
CREATE INDEX ix_nextasks_links_note_id ON nextasks_links (note_id);
COMMIT;
